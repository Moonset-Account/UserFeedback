-[0000:00]-+-00.0  Intel Corporation 440FX - 82441FX PMC [Natoma]
           +-01.0  Intel Corporation 82371AB/EB/MB PIIX4 ISA
           +-01.3  Intel Corporation 82371AB/EB/MB PIIX4 ACPI
           +-03.0  Red Hat, Inc. Virtio SCSI
           +-04.0  Red Hat, Inc. Virtio network device
           \-05.0  Red Hat, Inc. Virtio RNG
