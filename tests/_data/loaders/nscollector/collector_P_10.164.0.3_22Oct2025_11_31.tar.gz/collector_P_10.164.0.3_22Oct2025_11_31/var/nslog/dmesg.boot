Copyright (c) 1992-2020 The FreeBSD Project.
Copyright (c) 1979, 1980, 1983, 1986, 1988, 1989, 1991, 1992, 1993, 1994
	The Regents of the University of California. All rights reserved.
FreeBSD is a registered trademark of The FreeBSD Foundation.
FreeBSD 11.4-NETSCALER-14.1 #0 0ccc6e1263ee(HEAD): Tue Sep 23 00:31:08 EEST 2025
    root@openstack-prod-bsd114-17216.openstacklocal:/usr/obj/usr/home/build/adc/usr.src/sys/NS64 amd64
FreeBSD clang version 10.0.0 (git@github.com:llvm/llvm-project.git llvmorg-10.0.0-0-gd32170dbd5b)
can't re-use a leaf (i40e_skip_fw_ver_check)!
VT(vga): text 80x25
CPU: Intel(R) Xeon(R) CPU @ 2.00GHz (2000.10-MHz K8-class CPU)
  Origin="GenuineIntel"  Id=0x50653  Family=0x6  Model=0x55  Stepping=3
  Features=0x1f83fbff<FPU,VME,DE,PSE,TSC,MSR,PAE,MCE,CX8,APIC,SEP,MTRR,PGE,MCA,CMOV,PAT,PSE36,MMX,FXSR,SSE,SSE2,SS,HTT>
  Features2=0xfefa3203<SSE3,PCLMULQDQ,SSSE3,FMA,CX16,PCID,SSE4.1,SSE4.2,x2APIC,MOVBE,POPCNT,AESNI,XSAVE,OSXSAVE,AVX,F16C,RDRAND,HV>
  AMD Features=0x2c100800<SYSCALL,NX,Page1GB,RDTSCP,LM>
  AMD Features2=0x121<LAHF,ABM,Prefetch>
  Structured Extended Features=0xd11f6ffb<FSGSBASE,TSCADJ,BMI1,HLE,AVX2,FDPEXC,SMEP,BMI2,ERMS,INVPCID,RTM,NFPUSG,MPX,AVX512F,AVX512DQ,RDSEED,ADX,SMAP,CLWB,AVX512CD,AVX512BW,AVX512VL>
  Structured Extended Features3=0xac000400<MD_CLEAR,IBPB,STIBP,ARCH_CAP,SSBD>
  XSAVE Features=0xf<XSAVEOPT,XSAVEC,XINUSE,XSAVES>
  IA32_ARCH_CAPS=0x400004c<RSBA,SKIP_L1DFL_VME>
  TSC: P-state invariant
Hypervisor: Origin = "KVMKVMKVM"
real memory  = 8053063680 (7680 MB)
avail memory = 7328440320 (6988 MB)
Event timer "LAPIC" quality 600
ACPI APIC Table: <Google GOOGAPIC>
FreeBSD/SMP: Multiprocessor System Detected: 2 CPUs
FreeBSD/SMP: 1 package(s) x 2 hardware threads
platform: bios version Google dated 08/18/2025 found at 0xfffff800000f28b6
Security policy loaded: MAC/veriexec (mac_veriexec)
MAC/veriexec fingerprint module loaded: SHA256
ioapic0 <Version 1.1> irqs 0-23 on motherboard
SMP: AP CPU #1 Launched! (APIC_ID 1 LAPIC_ID 1)
random: entropy device external interface
md0: Embedded image 427819008 bytes at 0xffffffff816894a0
kbd1 at kbdmux0
module_register_init: MOD_LOAD (vesa, 0xffffffff80a8a6e0, 0) error 19
NS-KERN: md0: Preloaded image 427819008 bytes
random: registering fast source Intel Secure Key RNG
random: fast provider: "Intel Secure Key RNG"
Loading QAE MEM Module Version 0.7.1 ...
NS_SMT_TOPOLOGY: smt_topology loaded, CPU count: 2
NS_SMT_TOPOLOGY: SMT cpu pair (0, 1) -> (21585942, 21465754)
nexus0
vtvga0: <VT VGA driver> on motherboard
cryptosoft0: <software crypto> on motherboard
acpi0: <Google GOOGRSDT> on motherboard
acpi0: Power Button (fixed)
acpi0: Sleep Button (fixed)
cpu0: <ACPI CPU> on acpi0
cpu1: <ACPI CPU> on acpi0
atrtc0: <AT realtime clock> port 0x70-0x71,0x72-0x77 irq 8 on acpi0
atrtc0: registered as a time-of-day clock, resolution 1.000000s
Event timer "RTC" frequency 32768 Hz quality 0
Timecounter "ACPI-fast" frequency 3579545 Hz quality 900
acpi_timer0: <24-bit timer at 3.579545MHz> port 0xb008-0xb00b on acpi0
pcib0: <ACPI Host-PCI bridge> port 0xcf8-0xcff on acpi0
pci0: <ACPI PCI bus> on pcib0
isab0: <PCI-ISA bridge> at device 1.0 on pci0
isa0: <ISA bus> on isab0
pci0: <bridge> at device 1.3 (no driver attached)
virtio_pci0: <VirtIO PCI (legacy) SCSI adapter> port 0xc000-0xc03f mem 0xfebfc000-0xfebfc07f irq 11 at device 3.0 on pci0
vtscsi0: <VirtIO SCSI Adapter> on virtio_pci0
virtio_pci1: <VirtIO PCI (legacy) Network adapter> port 0xc040-0xc07f mem 0xfebfd000-0xfebfd07f irq 11 at device 4.0 on pci0
vtnet0: <VirtIO Networking Adapter> on virtio_pci1
NSXN: NetScaler running over Virtual Platform
platform: KVM
platform: NS KVM VPX on Google Compute Engine
platform: NetScaler Virtual Appliance 450070 (38), manufactured at 9/22/2012
platform: serial HE2JV262E4
platform: sysid 450070 - NetScaler Virtual Appliance
0/1: Ethernet address: 42:01:0a:a4:00:03
virtio_pci2: <VirtIO PCI (legacy) Entropy adapter> port 0xc080-0xc09f mem 0xfebfe000-0xfebfe03f irq 10 at device 5.0 on pci0
atkbdc0: <Keyboard controller (i8042)> port 0x60,0x64 irq 1 on acpi0
atkbd0: <AT Keyboard> irq 1 on atkbdc0
kbd0 at atkbd0
psm0: <PS/2 Mouse> irq 12 on atkbdc0
psm0: model IntelliMouse Explorer, device ID 4
uart0: <16550 or compatible> port 0x3f8-0x3ff irq 4 flags 0x90 on acpi0
uart0: console (9600,n,8,1)
uart1: <16550 or compatible> port 0x2f8-0x2ff irq 3 on acpi0
orm0: <ISA Option ROM> at iomem 0xeb800-0xeffff on isa0
vga0: <Generic ISA VGA> at port 0x3b0-0x3bb iomem 0xb0000-0xb7fff on isa0
Timecounters tick every 1.000 msec
usb_needs_explore_all: no devclass
da0 at vtscsi0 bus 0 scbus0 target 1 lun 0
NS-KERN PREFETCHW/PREFETCHWT1 supported
ns_physmem_init:
	reserving 1337344 (0x146800) of 1783507 (0x1b36d3) free pages
	(5224 (0x1468) of 6966 (0x1b36) MB) for Netscaler use
da0: <Google PersistentDisk 1> Fixed Direct Access SPC-4 SCSI device
da0: 300.000MB/s transfersNS-KERN CPU Cycle Clock Based Rate: 2002MHz (200150060 Hz / 10 ticks)

da0: Command Queueing enabled
da0: 20480MB (41943040 512 byte sectors)
NS-KERN skipping /dev/md0c...
Trying to mount root from ufs:/dev/md0 []...

rc script started: rc.version 7.0-$Date netscaler.version=NetScaler NS14.1: Build 51.80.nc, Date: Sep 23 2025, 00:30:55   (64-bit)
Define disks configuration: swap.da0s1b 
/ns-14.1-51.80 -> /flash/ns-14.1-51.80
random: unblocking device.
/dev/md0 on / (ufs, local)
devfs on /dev (devfs, local, multilabel)
procfs on /proc (procfs, local)
/dev/da0s1a on /flash (ufs, local, soft-updates)
/dev/da0s1e on /var (ufs, local, soft-updates)
Permanent config /flash/nsconfig/ will be used
signedExe enrollment start - this may take up to 60s.
kernel dumps on /dev/da0s1b
debug.debugger_on_panic: 1 -> 0
machdep.kdb_on_nmi: 1 -> 0
machdep.panic_on_nmi: 1 -> 1

Performing signature verification known answer test


Skipping signature verification known answer test.


Validating RSA PUB key present in the platform


Copied RSA public key file not present in /flash/secboot !

Skipping RSA PUB Key integrity check ...


Validating Kernel present in the platform


Kernel integrity check passed !

