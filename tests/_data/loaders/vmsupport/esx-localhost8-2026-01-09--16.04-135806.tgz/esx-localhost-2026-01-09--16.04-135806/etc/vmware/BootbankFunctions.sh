#!/bin/sh

# Copyright (c) 2009-2024 Broadcom. All Rights Reserved.
# Broadcom Confidential. The term "Broadcom" refers to Broadcom Inc.
# and/or its subsidiaries.

if [ -z "${LOG_TAG}" ]; then
   echo "Must set LOG_TAG before including BootbankFunctions.sh."
   exit 1
fi

log_info()
{
   logger -t "${LOG_TAG}" -n $$ -p user.info "$@"
   echo "${*}" >&2
}

log_err()
{
   logger -t "${LOG_TAG}" -n $$ -p user.error "$@"
   echo "${*}" >&2
}

sysalert()
{
   esxcfg-init --alert "${*}"
   echo "${*}" >&2
}

#
# Verify using gzip, tar, vmtar, including "wrapped" tar archives.
# Failures are silent.  Caller must check $? for a non-zero return status.
#
VerifyCopiedArchive()
{
   local archive="$1"
   local isWrapped=${2:-0}
   local res=0

   if [ ! -f "${archive}" ] ; then
      return 1
   fi
   
   # Check if the archive is one of the b.z (previously vmkboot.gz)
   # k.z (previously vmk.gz)
   # s.z (previously sys.vgz)
   # m.z (previously mod.tgz)
   # If yes, then we need to handle them specially here as the 
   # extensions won't tell what kind of archige it is anymore.

   local file=$(basename "${archive}")
   case "${file}" in
      *.tgz)
         if [ "$isWrapped" = "0" ]; then
            tar tzvf "${archive}" 2>&1 > /dev/null
            res=$?
         else
            tar xzOf "${archive}" | tar tzv 2>&1 > /dev/null
            res=$?  
         fi          
         ;;
      *.gz | b.z | k.z)
         gunzip -c "${archive}" 2>&1 > /dev/null
         res=$?
         ;;
      m.z)
         tar tzvf "${archive}" 2>&1 > /dev/null
         res=$?
         ;;
      s.z)
         vmtar -t < "${archive}" 2>&1 > /dev/null
         res=$?
         ;;
   esac

   return $res
}
